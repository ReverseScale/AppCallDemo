//
//  ViewController.m
//  Demoa
//
//  Created by WhatsXie on 2018/3/30.
//  Copyright © 2018年 WhatsXie. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UITextField *textFild;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}
- (IBAction)action:(id)sender {
    //打开B应用,有B应用计算结果,并且返回
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"Demob://%@", _textFild.text]];//"b"为B应用的url schemes
    if ([[UIApplication sharedApplication] canOpenURL:url]) {
        //        [[UIApplication sharedApplication] openURL:url];
        [[UIApplication sharedApplication] openURL:url options:@{} completionHandler:^(BOOL success) {
            
        }];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
