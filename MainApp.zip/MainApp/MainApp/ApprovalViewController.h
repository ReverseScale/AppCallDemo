//
//  ApprovalViewController.h
//
//  Created by XuJiahua on 2016/12/16.
//  Copyright © 2016年 johntech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ApprovalViewController : UIViewController

@property NSString *name;
@property NSString *callback;
@property NSString *clientId;

@end
