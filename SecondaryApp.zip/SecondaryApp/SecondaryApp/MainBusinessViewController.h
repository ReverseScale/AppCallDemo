//
//  MainBusinessViewController.h
//  SecondaryApp
//
//  Created by WhatsXie on 2018/3/30.
//  Copyright © 2018年 WhatsXie. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainBusinessViewController : UIViewController

@property NSString *grantCode;

@end
