//
//  MainBusinessViewController.m
//  SecondaryApp
//
//  Created by WhatsXie on 2018/3/30.
//  Copyright © 2018年 WhatsXie. All rights reserved.
//

#import "MainBusinessViewController.h"

@interface MainBusinessViewController ()
@property (weak, nonatomic) IBOutlet UILabel *lblCode;
@end

@implementation MainBusinessViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.lblCode.text = self.grantCode;
    // 可以用该APP的服务端
    // TODO: OAuth /token: client_id, client_secret, code
    
    // 客户端拿着accessToken就能一直访问资源了，直到过期。
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
